package assignment_5;

import java.util.Random;

public class Map {// attributes below
		private boolean walls [][];
		private boolean treasure [][];
		private int size;
		
		public Map (int size) {// attributes constructor
			this.size = size;
			
			walls = new boolean [size][size];
			treasure = new boolean [size][size];
			
			Random rand = new Random(); // random for walls and treasure

			for (int x = 0; x < size; x++) { 
			    for (int y = 0; y < size; y++) {

			        if (x == 0 && y == 0) continue;

			        if (rand.nextDouble() < 0.2) {
			            walls[x][y] = true; // setting the walls that they go random on map 20% smaller form map size
			        }
			        else if (rand.nextDouble() < 0.15) {
			            treasure[x][y] = true; // setting the treasure to be 15% smaller in number form size 
			        } // that basically means set numbers of walls and treasure that % smaller than the size of map
			    }
			}

		}
	    public boolean isWall(int x, int y) {
	        return walls[x][y]; // method is wall
	    }

	    public boolean hasTreasure(int x, int y) {
	        return treasure[x][y]; // method has treasure
	    }

	    public void removeTreasure(int x, int y) {
	        treasure[x][y] = false; // method remove treasure
	    }
	    
	    public int countTreasures() {
	        int total = 0;
	        for (int i = 0; i < size; i++) {
	            for (int j = 0; j < size; j++) {
	                if (treasure[i][j] == true) {
	                    total = total + 1;
	                } 
	            }
	        }
	        return total; // method and loop for counting the treasures
	    }
	    
	    public int getSize() {
	        return size; // getter for size 
	    }
	}


