package assignment_5;

public class Player extends Entity { // subclass of entity
	public Player () {
		super(0,0); // attributes from superclass
}
	@Override
	public void move(char direction, Map map) { // override the constructor
		
	    int newx = getx(); // new coordinates x
	    int newy = gety();// new coordinates x
		
	    if (direction == 'W') newy = newy + 1; // moves for player UP
	    else if (direction == 'S') newy = newy - 1; // moves for player DOWN
	    else if (direction == 'A') newx = newx - 1; // moves for player LEFT
	    else if (direction == 'D') newx = newx + 1; // moves for player RIGHT  
	    
	if (newx < 0) return; 
	if (newx >= map.getSize()) return;
	if (newy < 0) return;
	if (newy >= map.getSize()) return; // this is for player not to leave the map
	
    if (map.isWall(newx, newy)) {
        System.out.println("You hit a wall!");
        return; // if player hit wall it will told that it is a wall
    }
    
    setPosition (newx, newy);// setting new position

    if (map.hasTreasure(newx, newy)) {
        System.out.println("You found a treasure!");
        map.removeTreasure(newx, newy);  // if player found treasure print that and remove, count down
    	}
	}
	
}



