package assignment_5;

import java.util.Random;

public class Guard extends Entity { //subclass of entity

	public Guard(int x, int y) {
		super(x, y); // attributes from superclass
	}

	@Override
	public void move(char direction, Map map) { // override of constructor form superclass
		
		Random rand = new Random(); // guard is random
		boolean guardmoved = false;
		
		int newx = getx(); //new coordinate for x
		int newy = gety (); // new coordinate for y
		
		while (guardmoved == false) {
			int choice = rand.nextInt(4);
		System.out.println("Guard moved false:" + choice); // to see guard is moving or not
		
		if (choice == 0) newy = newy + 1; // random move different from player
		else if (choice == 1) newy = newy - 1;// random move different from player
		else if (choice == 2) newx = newx - 1;// random move different from player
		else if (choice == 3) newx = newx + 1;// random move different from player
		
		if (newx < 0) return;
		if (newx >= map.getSize()) return;
		if (newy < 0) return;
		if (newy >= map.getSize()) return; // for staying in the map for guard
		
		if (map.isWall(newx, newy)) {
			break;// if it is a wall try another direction
		}
		guardmoved=true;
		}
		
		setPosition (newx, newy); // setting the new position
		
	}
}
