package assignment_5;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
	 
	 Scanner s = new Scanner(System.in); // new scanner
	 Random rand = new Random(); // random for guard - guard to have random position
	 System.out.println("What size of the map you want? Put any number.");
  
	 int size = s.nextInt();// player choosing the size of map
     s.nextLine();// the code is stopping the enter to be used in the while loop
     Map map = new Map (size); // new map
 
     ArrayList<Entity> entities = new ArrayList<>(); // array list for entities
     Player player = new Player(); // new player
     
     int gx = rand.nextInt(size); //guard set position on random based on the size of the map for x
     int gy = rand.nextInt(size);//guard set position on random based on the size of the map for y
     Guard guard = new Guard(gx, gy); // new guard
     
     entities.add(player); // adding player form entity
     entities.add(guard); // adding guard from entity

     while (true) {
         System.out.println("Player is on this position: " + player.getx() + "," + player.gety()); // printing position of player
         System.out.println("Treasures left: " + map.countTreasures()); // printing the count of the treasures
         
         System.out.println("Your move(W,A,S,D):"); // choosing the move
         String input = s.next().toUpperCase();
         char move = input.charAt(0); //moving method

         for (Entity e : entities) {
             e.move(move, map); //  only entities move
         }

         if (player.getx() == guard.getx()) {
             if (player.gety() == guard.gety()) {
                 System.out.println("You are caught by guard! Game over for you!");
                 break; // loop for guard if he catches the player, YOU LOSE!
             }
         }

         if (map.countTreasures() == 0) {
             System.out.println("You collected all treasures! You win!");
             break; // loop for treasures if you collected all, YOU WIN!
         }
     }
     s.close();
     }

}
