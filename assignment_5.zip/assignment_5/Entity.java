package assignment_5;

public abstract class Entity { // super class
	private int x;// attribute x
	private int y;// attribute y

	public Entity(int x, int y) {// constructor
		this.x = x; 
		this.y = y;
	}
	
	public int getx() { // getter for x
		return this.x;
	}
	
	public int gety() { // getter for y
		return this.y;
	}
	
	protected void setPosition(int x, int y) { // setting the positions
        this.x = x;
        this.y = y;
	}    
	public abstract void move(char direction, Map map); // methods move for directions and map

}
